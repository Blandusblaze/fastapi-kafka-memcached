from kafka import KafkaConsumer
import json
from middleware.ys_middleware.core.config import settings

class KafkaConsumerClient:
    def __init__(self, topic, bootstrap_servers=settings.kafka_bootstrap_servers):
        self.consumer = KafkaConsumer(
            topic,
            bootstrap_servers=bootstrap_servers,
            auto_offset_reset='earliest',
            enable_auto_commit=True,
            value_deserializer=self.json_deserializer
        )

    def json_deserializer(self, x):
        try:
            return json.loads(x.decode('utf-8'))
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return None

    def consume_messages(self, filter_key=str) -> dict:
        result = dict()
        for message in self.consumer:
            if message.key is not None and message.key.decode('utf-8') == filter_key:
                print(f"Matching message with key: {message.key} of type : {type(message.key)} and value: {message.value}")
                print(f"String data : {message.key.decode('utf-8')}")
                result[filter_key] = message.value
                break
        self.close()

        return result

    def close(self):
        self.consumer.close()
