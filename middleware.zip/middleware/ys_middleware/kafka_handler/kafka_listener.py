from middleware.ys_middleware.memcached_handler.memcached_processor import MemcachedProcessor
from middleware.ys_middleware.kafka_handler.kafka_consumer import KafkaConsumerClient


class KafkaListener:
    def __init__(self, topic, memcached_host, memcached_port):
        self.kafka_consumer = KafkaConsumerClient(topic)
        self.memcached_processor = MemcachedProcessor(memcached_host, memcached_port)

    def process_messages(self, filter_key):
        try:
            kafka_messages = self.kafka_consumer.consume_messages(filter_key)
            for key, value in kafka_messages.items():
                # Retrieve data from Memcached for each key
                memcached_data = self.memcached_processor.get_value(key)
                if memcached_data:
                    print(f"Retrieved value from Memcached for key '{key}': {memcached_data}")
                else:
                    print(f"No value found in Memcached for key '{key}'")
        except Exception as e:
            print(f"Error processing messages: {e}")
        finally:
            self.kafka_consumer.close()
            self.memcached_processor.client.close()


