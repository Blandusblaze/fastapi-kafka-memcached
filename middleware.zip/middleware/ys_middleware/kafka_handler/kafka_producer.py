from kafka import KafkaProducer
import json
from typing import Any
from middleware.ys_middleware.core.config import settings


class KafkaProducerClient:
    def __init__(self, bootstrap_servers=None):
        if bootstrap_servers is None:
            bootstrap_servers = settings.kafka_bootstrap_servers
        self.producer = KafkaProducer(
            bootstrap_servers=bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=str.encode
        )

    def send_message(self, topic: str, key: str, data: Any):
        self.producer.send(topic, key=key, value=data)
        self.producer.flush()

    def close(self):
        self.producer.close()
