from pymemcache.client import base

class MemcachedProcessor:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        try:
            self.client = base.Client((self.host, self.port))
        except Exception as e:
            print(f"Failed to connect to Memcached: {e}")
            exit(1)

    def set_value(self, key, value, expire_time):
        """Sets a value in Memcached with the given key."""
        try:
            if self.client.set(key=key, value=value, expire=expire_time, noreply=False):
                print(f"Successfully set value for key '{key}'.")
            else:
                print(f"Failed to set value for key '{key}'.")
        except Exception as e:
            print(f"Error setting key '{key}': {e}")

    def get_value(self, key):
        """Gets a value from Memcached by key."""
        try:
            value = self.client.get(key)
            if value is not None:
                return value.decode('utf-8')
            else:
                print(f"No value found for key '{key}'.")
                return None
        except Exception as e:
            print(f"Error retrieving key '{key}': {e}")
            return None

