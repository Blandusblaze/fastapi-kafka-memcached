import uuid
from middleware.ys_middleware.core.config import settings
from middleware.ys_middleware.core.logging_config import logger
from middleware.ys_middleware.kafka_handler.kafka_producer import KafkaProducerClient
from middleware.ys_middleware.kafka_handler.kafka_consumer import KafkaConsumerClient
from middleware.ys_middleware.kafka_handler.kafka_listener import KafkaListener
from middleware.ys_middleware.memcached_handler.memcached_processor import MemcachedProcessor


class SearchService:

    def __init__(self, query: str = ''):
        self.query = query.lower().strip()
        # Implement JSON serializer if needed

    def search(self, query: dict) -> str:
        generated_uuid = str(uuid.uuid4())
        kafka_producer_client = KafkaProducerClient()
        kafka_producer_client.send_message("search_topic", generated_uuid, query)
        print(f"Message {query} published in kafka topic - search_topic with key - {generated_uuid}")
        logger.debug("Message %s published in kafka topic - search_topic with key - %s", query, generated_uuid)
        memcached_processor = MemcachedProcessor(settings.memcached_host_ip, settings.memcached_port)
        memcached_processor.set_value(key=generated_uuid, value=str({"ys_key": "ys_value123"}), expire_time=1800)
        return generated_uuid

    def fetch_search_result(self, search_id: str) -> dict:
        memcached_processor = MemcachedProcessor(settings.memcached_host_ip, settings.memcached_port)
        result = memcached_processor.get_value(search_id)
        if result is not None:
            print(f"Key {search_id} found configured in memcached with value - {result}")
            logger.debug("Key %s found configured in memcached with value - %s", search_id, result)
            return result
        else:
            kafka_consumer_client = KafkaConsumerClient("search_topic")
            result = kafka_consumer_client.consume_messages(search_id)
        print(f"Result : {result}")
        logger.debug("Result Query : %s", result)
        return result

    def fetch_search_result_from_kafka_listener(self, search_id: str) -> dict:
        listener = KafkaListener("search_topic", settings.memcached_host_ip, settings.memcached_port)
        result = listener.process_messages(search_id)
        return result

    """
    This will add up the metadata that is needed for a normal JSON response - But Clarify what does the metadata mean
    """

    #     return self.format_search_results(results)
    #
    # def format_search_results(self, results: list) -> dict:
    #     formatted_results = {
    #         "@context": "https://schema.org",
    #         "@type": "ItemList",
    #         "itemListElement": [],
    #         "totalResults": len(results),
    #         "metadata": {
    #             "currentPage": 1,
    #             "resultsPerPage": len(results)
    #         }
    #     }
    #
    #     for index, result in enumerate(results, start=1):
    #         formatted_results["itemListElement"].append({
    #             "@type": "ListItem",
    #             "position": index,
    #             "item": result
    #         })
    #
    #     return formatted_results
