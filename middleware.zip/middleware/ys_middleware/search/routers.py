from fastapi import APIRouter

from middleware.ys_middleware.core.logging_config import logger
from middleware.ys_middleware.search.search_service import SearchService

router = APIRouter()

'''
This is a sample endpoint for Search module
This will be change where the function will be implemented in search_service.py class
'''


@router.post("/search")
def search(input_query: dict):
    logger.debug(f"search query : {input_query}")
    service = SearchService()
    return service.search(query=input_query)


@router.get("/search/{search_id}")
def search(search_id: str):
    logger.debug(f"search query: {search_id}")
    service = SearchService()
    return service.fetch_search_result(search_id=search_id)


@router.get("/search/kafkalistener/{search_id}")
def search(search_id: str):
    logger.debug(f"search query: {search_id}")
    service = SearchService()
    return service.fetch_search_result_from_kafka_listener(search_id=search_id)
