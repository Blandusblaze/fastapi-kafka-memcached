from pydantic_settings import BaseSettings

from typing import List


class Settings(BaseSettings):
    app_name: str = "Yourscope"
    debug: bool = True
    cors_origins: str = "*"
    log_level: str = "INFO"
    kafka_bootstrap_servers: List[str] = ["localhost:29092"]
    memcached_host_ip: str = "localhost"
    memcached_port: str = "11211"

    class Config:
        env_file = ".env"
        env_file_encoding = 'utf-8'
        extra = 'ignore'


settings = Settings()
