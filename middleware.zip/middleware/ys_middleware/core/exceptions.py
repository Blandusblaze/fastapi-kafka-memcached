from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from middleware.ys_middleware.core.logging_config import logger

class CustomException(Exception):
    def __init__(self, name: str):
        self.name = name

def custom_exception_handler(request: Request, exc: CustomException):
    logger.error(f"Custom error occurred: {exc.name}")
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={"message": f"Custom error occurred: {exc.name}"}
    )

def validation_exception_handler(request: Request, exc: RequestValidationError):
    logger.warning(f"Validation error: {exc.errors()}")
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"message": "Validation error", "details": exc.errors()}
    )

def register_exception_handlers(app: FastAPI):
    app.add_exception_handler(CustomException, custom_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
