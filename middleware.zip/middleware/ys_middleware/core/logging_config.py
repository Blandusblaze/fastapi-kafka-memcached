import logging
from logging.config import dictConfig
import os

# Ensure the log directory exists
log_directory = 'logs'
if not os.path.exists(log_directory):
    os.makedirs(log_directory)

def setup_logging():
    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(module)s - %(funcName)s - %(message)s",
            },
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "default",
            },
            "debug_file": {
                "class": "logging.handlers.TimedRotatingFileHandler",
                "formatter": "default",
                "filename": os.path.join(log_directory, "debug.log"),
                "when": "midnight",
                "backupCount": 7,
                "level": "DEBUG",
            },
        },
        "root": {
            "handlers": ["console", "debug_file"],
            "level": "DEBUG",
        },
        "loggers": {
            "watchfiles.main": {
                "level": "DEBUG",
                "propagate": False,
            },
        },
    }

    dictConfig(logging_config)

setup_logging()
logger = logging.getLogger(__name__)
